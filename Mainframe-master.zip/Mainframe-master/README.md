# Mainframe - 

My Self Vijay Kumar I would like to share all the Mainframe related information here that i have gained over a decade of my jounrey in Mainframe.

If you are new or Want to referesh your Mainframe Skills ,i have created mainframe videos and shared in below links .

If you do like this don't forget to share this information to anyone this may be helpful.. 

Below are the different links you can looks at 

JCL Refresher

https://www.youtube.com/watch?v=viYX2Dv0MQA&feature=youtu.be

VSAM Refresher

https://www.youtube.com/watch?v=pxaZcJReq7Y&feature=youtu.be

TSO/ISPF

https://www.youtube.com/playlist?list=PLLcYGaQ7eeuTbGPLiApXSwmOhDofjaPni

COBOL

https://www.youtube.com/playlist?list=PLLcYGaQ7eeuQ84KfRFJF-Oh34g8CzuMzz

JCL

https://www.youtube.com/playlist?list=PLLcYGaQ7eeuTQGWRJ_B04qPowNWuHHfaz

VSAM

https://www.youtube.com/playlist?list=PLLcYGaQ7eeuQr-AlEgf4GG-FzS3eimdlm

DB2

https://www.youtube.com/playlist?list=PLLcYGaQ7eeuQNnKKTrz5s-bgMqEny83Oe

CICS
https://www.youtube.com/playlist?list=PLLcYGaQ7eeuRzZzMLfUdH0-X0dR-bafpC

PL/I

https://www.youtube.com/playlist?list=PLLcYGaQ7eeuRHk48TKIQLVFccvAankCtf

REXX

https://www.youtube.com/playlist?list=PLLcYGaQ7eeuR_e4lTL80vRhvq8qkvoTxz


MAINFRAME TESTING

https://www.youtube.com/playlist?list=PLLcYGaQ7eeuRn8tDl3wo-FQC4xvaqeVw0

MAINFRAME - ETL

https://www.youtube.com/playlist?list=PLLcYGaQ7eeuT85C_NgKkWTFhWZ3u1fa1m

INTERVIEW QUESTIONS

https://www.youtube.com/playlist?list=PLLcYGaQ7eeuQ7LF-n4LUjZE1uN82QWRN5


Happy Learning!!!


